DarkMint GTK2 & GTK3 theme

See: http://gnome-look.org/content/show.php/DarkMint?content=150904

Clone: git clone https://github.com/originalseed/darkmint.git


copy: 
```php
    userContent.css -> ~/.mozilla/firefox/<bla_bla>/chrome 
```
