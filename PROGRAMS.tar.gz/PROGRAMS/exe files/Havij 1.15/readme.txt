Provided by w0rd

w0rd [at] null0x00.com

Havij v1.15 Advanced SQL Injection Tool released. New features of this
version are:

Webknight WAF bypass added.
Bypassing mod_security made better
Unicode support added
A new method for tables/columns extraction in mssql
Continuing previous tables/columns extraction made available
Custom replacement added to the settings
Default injection value added to the settings (when using %Inject_Here%)
Table and column prefix added for blind injections
Custom table and column list added.
Custom time out added.
A new md5 cracker site added
bugfix: a bug releating to SELECT command
bugfix: finding string column
bugfix: getting multi column data in mssql
bugfix: finding mysql column count
bugfix: wrong syntax in injection string type in MsAccess
bugfix: false positive results was removed
bugfix: data extraction in url-encoded pages
bugfix: loading saved projects
bugfix: some errors in data extraction in mssql fixed.
bugfix: a bug in MsAccess when guessing tables and columns
bugfix: a bug when using proxy
bugfix: enabling remote desktop bug in windows server 2008 (thanks to
pegasus315)
bugfix: false positive in finding columns count
bugfix: when mssql error based method failed
bugfix: a bug in saving data
bugfix: Oracle and PostgreSQL detection