#!/bin/bash
# Colors
ESC_SEQ="\x1b["
COL_RESET=$ESC_SEQ"39;49;00m"
COL_RED=$ESC_SEQ"31;01m"
COL_GREEN=$ESC_SEQ"0;92m"
COL_YELLOW=$ESC_SEQ"0;94m"
COL_BLUE=$ESC_SEQ"1;94m"
COL_PURPLE=$ESC_SEQ"1;35m"
COL_CYAN=$ESC_SEQ"36;01m"
COL_WHITE=$ESC_SEQ"1;97m"

echo -e $COL_BLUE Bitmask Requires A New Tor Instance $COL_RESET

echo -e $COL_RED "Restarting Tor and Privoxy"
sleep 4

killall tor

sleep 2
service tor restart
#/usr/sbin/tor --runasdaemon 1
service privoxy restart
