#!/bin/bash
# Colors
ESC_SEQ="\x1b["
COL_RESET=$ESC_SEQ"39;49;00m"
COL_RED=$ESC_SEQ"31;05m"
COL_GREEN=$ESC_SEQ"0;92m"
COL_YELLOW=$ESC_SEQ"0;94m"
COL_BLUE=$ESC_SEQ"1;94m"
COL_PURPLE=$ESC_SEQ"1;35m"
COL_CYAN=$ESC_SEQ"36;01m"
COL_WHITE=$ESC_SEQ"1;97m"

echo -e "$COL_GREEN Restarting Tor and Privoxy"
echo -e "$COL_WHITE "
read -p "Are you sure? y/n" -n 1 -r
echo    # (optional) move to a new line
if [[ $REPLY =~ ^[Yy]$ ]]
then
echo -e "$COL_RESET "	
echo -e "$COL_RED Warning Restarting Tor and Privoxy! $COL_RESET"
sleep 4

killall tor

sleep 2
dtach -n /tmp/fooi /usr/sbin/tor --runasdaemon 1
service privoxy restart
echo -e "$COL_WHITE "
/usr/games/fortune | /usr/games/cowsay -f $(ls /usr/share/cowsay/cows/ | shuf -n1)
echo -e "$COL_RESET "
sleep 5
fi