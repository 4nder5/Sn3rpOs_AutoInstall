#! /usr/bin/env python

"""
tor_switcher.py
A light interface for issuing NEWNYM signals over TOR's control port. Usefull
for making a PyLoris DoS attack look like a DDoS attack.
"""

import random, telnetlib, thread, time
from Tkinter import *

class Switcher(Tk):
    def __init__(self):
        Tk.__init__(self)
        self.title(string = ".o0O| sn3rpswitcher |O0o.")

        self.host = StringVar()
        self.port = IntVar()
        self.USER = IntVar()
        self.passwd = StringVar()
        self.time = DoubleVar()

        self.host.set('127.0.0.1')
        self.port.set('9151')
        self.USER.set('sn3rp')
        self.passwd.set('password')
        self.time.set('30')

        Label(self, text = 'Host:').grid(row = 1, column = 1)
        Label(self, text = 'Port:').grid(row = 2, column = 1)
        Label(self, text = 'USER:').grid(row = 3, column = 1)
        Label(self, text = 'Password:').grid(row = 4, column = 1)
        Label(self, text = 'Interval:').grid(row = 5, column = 1)

        Entry(self, textvariable = self.host).grid(row = 1, column = 2, columnspan = 2)
        Entry(self, textvariable = self.port).grid(row = 2, column = 2, columnspan = 2)
        Entry(self, textvariable = self.USER).grid(row = 3, column = 2, columnspan = 2)
        Entry(self, textvariable = self.passwd, show = '*').grid(row = 4, column = 2, columnspan = 2)
        Entry(self, textvariable = self.time).grid(row = 5, column = 2, columnspan = 2)

        Button(self, text = 'Start', command = self.start).grid(row = 6, column = 2)
        Button(self, text = 'Stop', command = self.stop).grid(row = 6, column = 3)

        self.output = Text(self, foreground="black", background="red", highlightcolor="green", highlightbackground="yellow", wrap=WORD, height = 8, width = 40)
	self.output.grid(row = 1, columnspan = 2, column = 4, rowspan = 5)

    def start(self):
        self.write('sn3rpswitcher starting.')
        self.ident = random.random()
        thread.start_new_thread(self.newnym, ())

    def stop(self):
        try:
            self.write('sn3rpswitcher stopping.')
        except:
            pass
        self.ident = random.random()

    def write(self, message):
        t = time.localtime()
        try:
            self.output.insert(END, '[%02i:%02i:%02i] %s\n' % (t[3], t[4], t[3], message))
        except:
            print('[%02i:%02i:%02i] %s\n' % (t[3], t[4], t[3], message))
            
    def newnym(self):
        key = self.ident
        host = self.host.get()
        port = self.port.get()
        passwd = self.passwd.get()
        interval = self.time.get()

        try:
            tn = telnetlib.Telnet(host, port)
            if passwd == '':
                tn.write("AUTHENTICATE\r\n")
            else:
                tn.write("AUTHENTICATE \"%s\"\r\n" % (passwd))
            res = tn.read_until('250 OK', 5)

            if res.find('250 OK') > -1:
                self.write('AUTHENTICATION ACCEPTED.')
            else:
                self.write('What the fuck are you doing?')
                key = self.ident + 1
                self.write('I quit!')
        except Exception, ex:
            self.write('LAME' % (ex))
            key = self.ident + 1
            self.write('I quit!')
        
        while key == self.ident:
            try:
                tn.write("signal NEWNYM\r\n")
                res = tn.read_until('250 OK', 5)
                if res.find('250 OK') > -1:
                    self.write('New Tor Identity')
                else:
                    self.write('What the fuck are you doing?')
                    key = self.ident + 1
                    self.write('Quitting.')
                time.sleep(interval)
            except Exception, ex:
                self.write('LAME' % (ex))
                key = self.ident + 1
                self.write('I quit!')

        try:
            tn.write("QUIT\r\n")
            tn.close()
        except:
            pass

if __name__ == '__main__':
    mw = Switcher()
    mw.mainloop()
    mw.stop()
