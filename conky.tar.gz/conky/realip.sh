#!/bin/bash
unset http_proxy
unset https_proxy
unset ftp_proxy


wget -qO- icanhazip.com
#wget -qO- ip6.icanhazip.com

