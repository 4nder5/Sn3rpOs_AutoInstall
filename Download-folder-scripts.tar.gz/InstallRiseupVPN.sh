#!/bin/bash
ESC_SEQ="\x1b["
COL_RESET=$ESC_SEQ"39;49;00m"
COL_RED=$ESC_SEQ"31;01m"
COL_GREEN=$ESC_SEQ"0;92m"
COL_YELLOW=$ESC_SEQ"1;93m"
COL_BLUE=$ESC_SEQ"34;01m"
COL_PURPLE=$ESC_SEQ"1;35m"
COL_CYAN=$ESC_SEQ"36;01m"
COL_WHITE=$ESC_SEQ"1;97m"

apt update; apt install dialog -y

HEIGHT=15
WIDTH=40
CHOICE_HEIGHT=4
BACKTITLE="RiseupVPN INSTALL"
TITLE="RiseupVPN INSTALL"
MENU="Choose one of the following options:"

OPTIONS=(1 "Reinstall RiseupVPN?"
         2 "Install RiseupVPN and start it for me?"
         3 "Uninstall RiseupVPN :( ?")

CHOICE=$(dialog --clear \
                --backtitle "RiseupVPN INSTALL" \
                --title "RiseupVPN INSTALL" \
                --menu "$MENU" \
                $HEIGHT $WIDTH $CHOICE_HEIGHT \
                "${OPTIONS[@]}" \
                2>&1 >/dev/tty)

clear
case $CHOICE in
        1)
            echo -e "$COL_RESET"
            echo -e "$COL_RED "
            service snapd start ;
            snap remove riseup-vpn ;
            snap install --classic riseup-vpn ;
            update-menus ;
            /usr/share/kali-menu/update-kali-menu ;
            pkill -e -f riseup-vpn ;
            /snap/bin/riseup-vpn.bitmask-root firewall stop ;
            echo -e "$COL_RESET"
            ;;
        2)
            echo -e "$COL_RESET"
            echo -e "$COL_RED "
            service snapd start ;
            snap remove riseup-vpn ;
            snap install --classic riseup-vpn ;
            update-menus ;
            /usr/share/kali-menu/update-kali-menu ;
            pkill -e -f riseup-vpn ;
            /snap/bin/riseup-vpn.bitmask-root firewall stop ;
            dtach -n /tmp/fooR /snap/bin/riseup-vpn.launcher ;
            echo -e "$COL_WHITE Hey Dummy It's Running!"
            echo -e "$COL_WHITE ^Look up to the left of NetworkManager applet^ $COL_RESET"
            sleep 6 
            echo -e "$COL_RESET"
            ;;
        3)
            echo -e "$COL_RESET"
            echo -e "$COL_RED "
            service snapd start ;
            pkill -e -f riseup-vpn ;
            /snap/bin/riseup-vpn.bitmask-root firewall stop ;
            snap remove riseup-vpn ;
            update-menus ;
            /usr/share/kali-menu/update-kali-menu ;
            ;;
esac