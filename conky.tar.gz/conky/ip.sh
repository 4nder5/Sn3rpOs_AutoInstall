#!/bin/bash
unset http_proxy
unset https_proxy
unset ftp_proxy

torsocks wget -qO- icanhazip.com
torsocks wget -qO- ip6.icanhazip.com

