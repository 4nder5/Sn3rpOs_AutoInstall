#!/bin/bash
# Colors
ESC_SEQ="\x1b["
COL_RESET=$ESC_SEQ"39;49;00m"
COL_RED=$ESC_SEQ"31;01m"
COL_GREEN=$ESC_SEQ"0;92m"
COL_YELLOW=$ESC_SEQ"1;93m"
COL_BLUE=$ESC_SEQ"34;01m"
COL_PURPLE=$ESC_SEQ"1;35m"
COL_CYAN=$ESC_SEQ"36;01m"
COL_WHITE=$ESC_SEQ"1;97m"

echo -e "$COL_GREEN This script will clear all proxy $COL_RESET"
echo -e "$COL_GREEN environmental settings in your current terminal."
echo -e "$COL_WHITE"
read -p "Continue y/n" -n 1 -r
echo    # (optional) move to a new line
if [[ $REPLY =~ ^[Yy]$ ]]
then

unset http_proxy
unset https_proxy
unset ftp_proxy
echo -e "$COL_GREEN Now prove it!"
sleep 2
echo -e "$COL_YELLOW This should be your raw public ip address"
echo -e "$COL_YELLOW Use a vpn XD"
echo -e "$COL_RED working..."
echo -e "$COL_BLUE"
wget -qO- icanhazip.com

sleep 4
fi
$BASH

